"use server";

import { escapeSql, generateId } from "@/utils/crypto";
import { getConnection } from "@/utils/db";
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";

export async function newQuestion(question: string) {
  const db = await getConnection();
  await db.run("INSERT INTO questions(id, uid, question) VALUES (?, ?, ?)", [
    generateId(64),
    cookies().get("uid")!.value,
    question,
  ]);
  revalidatePath("/");
}

export async function answerQuestion(answer: string, id: string) {
  const db = await getConnection();
  await db.exec(
    `UPDATE questions SET
        answer="${escapeSql(answer)}"
        WHERE id="${id}"`
  );
  revalidatePath("/");
}
